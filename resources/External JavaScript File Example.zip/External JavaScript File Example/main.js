// I am writing something to the console
console.log("Hi in external file.");